static var player1Stats : Array = [0,0,0]; // [Character, percent/stamina, stock]
function Update () {
	player1Stats[0] = 1;
	player1Stats[1] = 0;
}