var stock : Texture2D;
var icon : Texture2D;
var totalplayers = 1;
var player1percent = 1;

function OnGUI () {
 if (totalplayers >0) {
	GUI.Label (Rect(10,10,100,100), player1percent);
    GUI.Box (Rect (((Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-50,Screen.height - 100,100,100), "P1 Stats");
	GUI.Label (Rect (((Screen.width/totalplayers))-(Screen.width/(2 * totalplayers)),Screen.height - 60,100,100), "P1%");
	GUI.Label (Rect (((Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-75,Screen.height - 85,100,100), icon);
	GUI.Label (Rect (((Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-30,Screen.height - 20,100,100), "TestChar");
}
if (totalplayers > 1) {
    GUI.Box (Rect ((2*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-50,Screen.height - 100,100,100), "P2 Stats");
	GUI.Label (Rect ((2*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers)),Screen.height - 60,100,100), "P2%");
	GUI.Label (Rect ((2*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-75,Screen.height - 85,100,100), icon);
	GUI.Label (Rect ((2*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-30,Screen.height - 20,100,100), "TestChar");
}
if (totalplayers > 2) {
    GUI.Box (Rect ((3*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-50,Screen.height - 100,100,100), "P3 Stats");
	GUI.Label (Rect ((3*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers)),Screen.height - 60,100,100), "P3%");
	GUI.Label (Rect ((3*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-75,Screen.height - 85,100,100), icon);
	GUI.Label (Rect ((3*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-30,Screen.height - 20,100,100), "TestChar");
}
if (totalplayers > 3) {
    GUI.Box (Rect ((4*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-50,Screen.height - 100,100,100), "P4 Stats");
	GUI.Label (Rect ((4*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers)),Screen.height - 60,100,100), "P4%");
	GUI.Label (Rect ((4*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-75,Screen.height - 85,100,100), icon);
	GUI.Label (Rect ((4*(Screen.width/totalplayers))-(Screen.width/(2 * totalplayers))-30,Screen.height - 20,100,100), "TestChar");
}

}
